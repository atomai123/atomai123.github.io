# 我的博客

## 快速开始

```bash
cd ~/projects/my-blog
hugo server -D
```

## 文章目录

- [第一篇文章](/posts/first-post/)
- [文章模板](/posts/template/)
- [关于我](/about/)

## 分类

- [技术](/categories/tech/)
- [AI](/categories/ai/)
- [生活](/categories/life/)

## 链接

- [GitHub](https://github.com/原子君)
- [RSS](/index.xml)
