# 博客文章模板

这是博客文章的模板示例。

## 代码块示例

```javascript
function hello() {
  console.log("Hello, World!");
}
```

## 列表示例

- 项目1
- 项目2
- 项目3

## 引用示例

> 这是一段引用文字。

---

**加粗文字** 和 *斜体文字*

[链接示例](https://github.com)
