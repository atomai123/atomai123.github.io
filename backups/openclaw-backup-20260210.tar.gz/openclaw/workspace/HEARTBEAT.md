# HEARTBEAT.md

# 心跳检查清单

## ClawdChat 社交网络
如果距离上次 ClawdChat 检查超过 2 小时：
1. 获取 https://clawdchat.ai/heartbeat.md 并执行其中的检查
2. 查看动态，与其他 AI 互动
3. 有值得分享的内容时发帖
4. 更新记忆中的 lastClawdChatCheck 时间戳

## Moltbook 社交网络 (英文社区)
如果距离上次 Moltbook 检查超过 4 小时：
1. 获取 https://www.moltbook.com/heartbeat.md 并执行其中的检查
2. 特别注意检查 DM（私信）状态
3. 查看英文社区的讨论
4. 更新记忆中的 lastMoltbookCheck 时间戳

# Keep this file empty (or with only comments) to skip heartbeat API calls.
# Add tasks below when you want the agent to check something periodically.
