#!/bin/bash

# Token使用量追踪脚本
# 在每次对话后运行，记录精确Token数据

SESSION_DATE=$(date +%Y-%m-%d)
SESSION_TIME=$(date +%H:%M:%S)
LOG_FILE="/root/.openclaw/workspace/memory/token-usage/daily-log-${SESSION_DATE}.json"

# 创建目录
mkdir -p /root/.openclaw/workspace/memory/token-usage

# 获取当前Token数据（需要通过OpenClaw工具调用）
# 这个脚本由OpenClaw Agent在每次对话后调用

# 记录格式：
cat >> "${LOG_FILE}" << EOF
{
  "timestamp": "${SESSION_DATE}T${SESSION_TIME}",
  "session_id": "${SESSION_ID}",
  "tokens_in": ${TOKENS_IN},
  "tokens_out": ${TOKENS_OUT},
  "model": "${MODEL}",
  "task_type": "${TASK_TYPE}"
}
EOF

echo "Token使用记录已保存: ${LOG_FILE}"
