# 📊 Token使用量追踪系统

*记录每次对话和每日Token使用报告*

---

## 🎯 追踪规则

### 1. 每次对话末尾附加

所有任务/对话回复末尾自动附加：

```
---
📊 本次对话Token使用
- 输入Token: [待系统提供]
- 输出Token: [待系统提供]
- 总计Token: [待系统提供]
- 模型: [使用的模型]
- 时间: [对话时间]
```

### 2. 每日Token使用报告

**时间**: 每天晚上最后一次对话后  
**格式**: 结构化报告  
**保存位置**: `~/memory/token-usage/YYYY-MM-DD-token-report.md`

**报告内容**:
- 当日总对话次数
- 当日总Token使用量
- 各模型使用分布
- 单次对话最大/最小使用量
- 与昨日对比
- 本月累计

---

## 🛠️ 实现说明

**重要说明**: 作为AI助手，我无法直接获取底层API调用的Token使用量（这是OpenClaw Gateway层面的数据）。实际实现需要：

### 方案1: 使用OpenClaw内置功能
- 使用 `/status` 命令查看当前会话统计
- 使用 `session_status` 工具获取详细数据
- 需要用户在对话后手动查看或系统自动记录

### 方案2: 估算模式（当前采用）
- 基于字符数估算Token使用量
- 1个中文Token ≈ 1-2个字符
- 1个英文Token ≈ 4个字符
- 提供估算值供参考

### 方案3: Gateway日志分析
- 从OpenClaw Gateway日志中提取Token数据
- 需要访问Gateway日志权限
- 最准确但需要系统级访问

---

## 📋 估算公式

```python
# Token估算公式
def estimate_tokens(text):
    # 中文字符: 1-2字符 = 1 token
    chinese_chars = len([c for c in text if '\u4e00' <= c <= '\u9fff'])
    chinese_tokens = chinese_chars / 1.5
    
    # 英文字符: 4字符 = 1 token
    english_chars = len([c for c in text if c.isascii() and c.isalpha()])
    english_tokens = english_chars / 4
    
    # 其他字符（标点、数字等）
    other_chars = len(text) - chinese_chars - english_chars
    other_tokens = other_chars / 2
    
    total_tokens = chinese_tokens + english_tokens + other_tokens
    return round(total_tokens)
```

---

## 📁 文件结构

```
~/.openclaw/workspace/memory/token-usage/
├── 2026-02-06-token-report.md     # 每日报告
├── 2026-02-05-token-report.md     # 历史报告
├── monthly-summary-2026-02.md     # 月度汇总
└── token-usage-log.json           # 原始日志数据
```

---

## 📊 报告模板

### 单次对话记录
```markdown
### 对话 #X - [任务名称]
- **时间**: HH:MM:SS
- **输入估算**: ~XXX tokens
- **输出估算**: ~XXX tokens
- **总计估算**: ~XXX tokens
- **模型**: moonshot/kimi-k2.5
- **任务类型**: [代码/写作/分析/其他]
```

### 每日总结报告
```markdown
# 📊 Token使用日报 - YYYY-MM-DD

## 概览
- **总对话次数**: X次
- **总Token使用量**: ~XXX,XXX tokens
- **平均每次对话**: ~X,XXX tokens
- **最大单次使用**: ~XX,XXX tokens (任务: XXX)
- **最小单次使用**: ~XXX tokens (任务: XXX)

## 模型使用分布
| 模型 | 使用次数 | Token占比 | 备注 |
|------|----------|-----------|------|
| Kimi K2.5 | X次 | XX% | 主要模型 |
| DeepSeek | X次 | XX% | 辅助使用 |

## 任务类型分布
| 类型 | 次数 | Token使用量 | 占比 |
|------|------|-------------|------|
| 代码编写 | X次 | XX,XXX | XX% |
| 文档整理 | X次 | XX,XXX | XX% |
| 分析总结 | X次 | XX,XXX | XX% |
| 其他 | X次 | XX,XXX | XX% |

## 时间分布
- **上午(6-12点)**: XX,XXX tokens (X%)
- **下午(12-18点)**: XX,XXX tokens (X%)
- **晚上(18-24点)**: XX,XXX tokens (X%)

## 与昨日对比
- **Token使用量**: ↑/↓ XX% (+/- XX,XXX)
- **对话次数**: ↑/↓ X次
- **平均使用**: ↑/↓ XX%

## 本月累计
- **总Token使用量**: XXX,XXX tokens
- **总对话次数**: XXX次
- **日均使用**: XX,XXX tokens

## 💡 优化建议
- [根据使用情况提供建议]

---
*报告生成时间*: [时间]
*数据说明*: 基于字符数估算，实际Token使用可能略有差异
```

---

## 🎯 原子君的Token追踪偏好

**记录时间**: 2026-02-06  
**偏好说明**:
1. 每次对话末尾需要看到Token使用量
2. 每天晚上需要当天完整的Token使用报告
3. 希望了解Token使用的趋势和优化建议
4. 数据保存到memory目录，便于长期追踪

**目的**:
- 了解AI助手使用成本
- 优化对话效率
- 识别高Token消耗的任务类型
- 建立使用习惯的数据支撑

---

## ⚙️ 定时任务配置

已配置每天晚上生成Token使用报告：
- **任务名称**: 每日Token使用报告生成
- **执行时间**: 每天 23:30 (北京时间)
- **任务内容**: 汇总当天所有对话，生成结构化报告
- **保存位置**: ~/memory/token-usage/YYYY-MM-DD-token-report.md

---

## 📝 使用说明

**对于每次对话**:
我会在回复末尾附加Token使用估算（基于字符数）

**对于每日报告**:
每天晚上23:30自动生成并发送给你

**查看历史**:
可以随时查看 `~/memory/token-usage/` 目录下的历史报告

**注意事项**:
- 当前采用估算模式，非精确值
- 实际Token使用以OpenClaw Gateway日志为准
- 如需精确数据，建议定期使用 `/status` 命令查看

---

*系统版本*: Token Tracker v1.0  
*创建时间*: 2026-02-06
