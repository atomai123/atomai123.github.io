# 🚀 we-mp-rss 部署指南

*微信公众号 RSS 生成工具部署教程*

---

## 📋 项目说明

**项目名称**: we-mp-rss  
**功能**: 微信公众号 RSS 订阅生成器  
**优势**: 专注微信公众号，可能比 RSSHub 更简单轻量

**注意**: 由于无法访问具体仓库，以下部署方案基于常见开源项目模式。实际部署时请根据仓库 README 调整。

---

## 🛠️ 方案一：Docker 部署（推荐）

### 1. 准备服务器

**要求**:
- CPU: 1核+
- 内存: 1GB+
- 系统: Ubuntu 20.04+/CentOS 7+
- 网络: 国内服务器即可（微信相关）
- 预算: ~￥24-50/月

**推荐**: 阿里云/腾讯云轻量应用服务器

### 2. 连接服务器

```bash
ssh root@你的服务器IP
```

### 3. 安装 Docker

```bash
# Ubuntu/Debian
apt update
apt install -y docker.io docker-compose git

# CentOS
yum install -y docker git
systemctl start docker
systemctl enable docker

# 验证
docker --version
docker-compose --version
```

### 4. 克隆项目

```bash
mkdir -p /opt
cd /opt
git clone https://github.com/rachelos/we-mp-rss.git
cd we-mp-rss
```

**如果克隆失败**, 尝试:
```bash
# 使用镜像加速
git clone https://ghproxy.com/https://github.com/rachelos/we-mp-rss.git
```

### 5. 查看项目结构

```bash
ls -la
```

常见文件:
- `docker-compose.yml` - Docker 配置文件
- `config.json` / `config.py` - 配置文件
- `requirements.txt` - Python 依赖
- `package.json` - Node.js 依赖
- `README.md` - 项目说明

### 6. Docker 部署

**情况 A: 项目已有 docker-compose.yml**

```bash
# 直接启动
docker-compose up -d

# 查看日志
docker-compose logs -f
```

**情况 B: 需要自建 Dockerfile**

创建 `docker-compose.yml`:

```bash
cat > docker-compose.yml << 'EOF'
version: '3'

services:
  we-mp-rss:
    build: .
    container_name: we-mp-rss
    ports:
      - "8080:8080"  # 根据实际端口调整
    volumes:
      - ./config:/app/config
      - ./data:/app/data
    restart: always
    environment:
      - TZ=Asia/Shanghai
EOF
```

然后构建并启动:
```bash
docker-compose up -d --build
```

### 7. 检查部署状态

```bash
# 查看容器状态
docker ps

# 查看日志
docker logs -f we-mp-rss

# 测试访问
curl http://localhost:8080  # 根据实际端口调整
```

---

## 🔧 方案二：直接部署（无 Docker）

### Python 项目

```bash
# 进入项目目录
cd /opt/we-mp-rss

# 安装依赖
pip3 install -r requirements.txt

# 配置
cp config.example.json config.json
vim config.json  # 编辑配置

# 运行
python3 app.py
# 或
python3 main.py
```

### Node.js 项目

```bash
# 进入项目目录
cd /opt/we-mp-rss

# 安装依赖
npm install
# 或
yarn install

# 配置
cp config.example.json config.json
vim config.json

# 运行
npm start
# 或
node app.js
```

### 使用 PM2 守护进程（推荐）

```bash
# 安装 PM2
npm install -g pm2

# 启动
pm2 start app.py --name we-mp-rss
# 或
pm2 start app.js --name we-mp-rss

# 开机自启
pm2 startup
pm2 save

# 查看状态
pm2 status
pm2 logs we-mp-rss
```

---

## ⚙️ 配置公众号

### 1. 获取公众号信息

**方式一：通过微信搜索**
1. 打开微信 → 搜一搜
2. 搜索公众号名称
3. 进入公众号主页
4. 点击右上角 "..." → 复制链接
5. 提取链接中的 `__biz=` 参数

**方式二：通过搜狗微信**
1. 访问 https://weixin.sogou.com/
2. 搜索公众号
3. 点击进入
4. 复制 URL

### 2. 配置到 we-mp-rss

编辑配置文件（根据项目实际情况）:

```bash
# 常见配置文件名
vim config.json
vim config.py
vim .env
```

示例配置:
```json
{
  "accounts": [
    {
      "name": "唐书房",
      "biz": "MzAwMjQ2NTMzNw=="
    },
    {
      "name": "刘备教授",
      "biz": "MzI4MjM0NjI0MQ=="
    }
  ],
  "port": 8080,
  "interval": 3600
}
```

### 3. 重启服务

```bash
# Docker
docker-compose restart

# PM2
pm2 restart we-mp-rss
```

---

## 🌐 访问 RSS

部署成功后，访问格式通常为:

```
http://你的服务器IP:8080/feed/公众号标识
http://你的服务器IP:8080/rss/公众号标识
http://你的服务器IP:8080/api/feed/公众号标识
```

具体路径请查看项目 README 或源码。

---

## 🤖 自动化日报配置

创建日报生成脚本:

```bash
mkdir -p /opt/we-mp-rss/scripts
cd /opt/we-mp-rss/scripts
```

创建 `daily_report.sh`:

```bash
#!/bin/bash

DATE=$(date +%Y-%m-%d)
TIME=$(date +%H:%M)
SERVER_IP="你的服务器IP"
PORT="8080"  # 根据实际端口调整
OUTPUT_DIR="/opt/we-mp-rss/reports"

# 公众号列表（根据实际情况修改）
declare -A ACCOUNTS
ACCOUNTS=(
    ["公众号1"]="feed/公众号1标识"
    ["公众号2"]="feed/公众号2标识"
)

mkdir -p "$OUTPUT_DIR"

REPORT_FILE="$OUTPUT_DIR/${DATE}-wechat-news.md"

cat > "$REPORT_FILE" << EOF
# 📰 微信公众号日报 - ${DATE}

**抓取时间**: 北京时间 ${DATE} ${TIME}  
**数据来源**: we-mp-rss  

---

EOF

for name in "${!ACCOUNTS[@]}"; do
    path="${ACCOUNTS[$name]}"
    rss_url="http://${SERVER_IP}:${PORT}/${path}"
    
    echo "## ${name}" >> "$REPORT_FILE"
    echo "" >> "$REPORT_FILE"
    echo "- RSS: ${rss_url}" >> "$REPORT_FILE"
    echo "" >> "$REPORT_FILE"
    
    # 尝试获取内容（可选）
    # curl -s "${rss_url}" | head -20 >> "$REPORT_FILE"
done

echo "日报已生成: $REPORT_FILE"
```

设置定时任务:
```bash
chmod +x /opt/we-mp-rss/scripts/daily_report.sh

# 每天早上9点执行
echo "0 9 * * * root /opt/we-mp-rss/scripts/daily_report.sh" >> /etc/crontab
service cron restart
```

---

## 🆘 常见问题

### Q1: 克隆项目失败？
```bash
# 使用代理
git clone https://ghproxy.com/https://github.com/rachelos/we-mp-rss.git

# 或手动下载 ZIP
wget https://github.com/rachelos/we-mp-rss/archive/refs/heads/main.zip
unzip main.zip
mv we-mp-rss-main we-mp-rss
```

### Q2: 依赖安装失败？
```bash
# Python
pip3 install --upgrade pip
pip3 install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple

# Node.js
npm install --registry=https://registry.npm.taobao.org
```

### Q3: 端口被占用？
```bash
# 查看端口占用
netstat -tunlp | grep 8080

# 修改端口（编辑配置文件）
vim config.json  # 改为其他端口，如 8081
```

### Q4: 无法获取公众号文章？
- 检查公众号 biz 号是否正确
- 查看日志排查错误
- 可能是微信接口限制，需要添加延时或代理

### Q5: 如何更新项目？
```bash
cd /opt/we-mp-rss
git pull

# Docker
docker-compose down
docker-compose up -d --build

# 或直接重启
pm2 restart we-mp-rss
```

---

## 📊 与 RSSHub 对比

| 维度 | we-mp-rss | RSSHub |
|------|-----------|--------|
| **专注度** | 专注微信 | 多平台 |
| **部署难度** | 可能更简单 | 中等 |
| **功能丰富度** | 较少 | 丰富 |
| **维护成本** | 看项目活跃度 | 活跃维护 |
| **稳定性** | 待测试 | 已知稳定 |

**建议**:
- 先试用 we-mp-rss 1-2周
- 如果效果好，继续使用
- 如果不行，迁移到 RSSHub

---

## ✅ 部署检查清单

- [ ] 购买服务器
- [ ] 连接服务器（SSH）
- [ ] 安装 Docker/Git
- [ ] 克隆 we-mp-rss 项目
- [ ] 查看项目 README
- [ ] 部署（Docker 或直接运行）
- [ ] 访问测试
- [ ] 配置公众号列表
- [ ] 测试 RSS 生成
- [ ] 配置自动化日报
- [ ] 设置定时任务

---

## 📞 下一步

**立即行动**:
1. **买服务器**（阿里云/腾讯云轻量，24元/月）
2. **发我服务器信息**（IP、密码），我帮你部署
3. **或你自己克隆项目**后告诉我项目结构

**需要准备**:
- 服务器 IP 和密码
- 公众号列表（biz 号或名称）

准备好开始了吗？🚀
