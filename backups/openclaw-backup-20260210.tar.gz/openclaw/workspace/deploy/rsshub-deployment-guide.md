# 🚀 RSSHub 部署指南 - 微信公众号抓取

*完整部署教程 + 自动化日报生成*

---

## 📋 部署前准备

### 1. 服务器要求

| 配置项 | 最低要求 | 推荐配置 |
|--------|----------|----------|
| **CPU** | 1核 | 2核 |
| **内存** | 1GB | 2GB |
| **硬盘** | 20GB | 40GB |
| **系统** | Ubuntu 20.04+ | Ubuntu 22.04 LTS |
| **网络** | 海外节点优先 | 香港/新加坡/美国 |
| **预算** | ~￥24/月 | ~￥50/月 |

**推荐服务商**：
- 阿里云：香港轻量应用服务器（24元/月）
- 腾讯云：海外轻量服务器
- Vultr/DigitalOcean：$5-10/月

### 2. 域名（可选）
- 可以暂时使用IP地址
- 长期使用建议配置域名（方便记忆）

### 3. 你关注的公众号列表
- 准备一份Excel/文本文件
- 格式：公众号名称 + 微信号/biz号

---

## 🛠️ 部署步骤

### 第一步：购买服务器

**推荐：阿里云香港轻量应用服务器**

1. 访问 https://www.aliyun.com/
2. 搜索「轻量应用服务器」
3. 选择「香港」区域
4. 选择配置：
   - CPU：2核
   - 内存：2GB
   - 带宽：30Mbps峰值
   - 流量：1TB/月
   - 系统盘：50GB SSD
5. 镜像选择：Ubuntu 22.04
6. 购买时长：建议先买1个月测试

**费用**：约￥24-50/月

---

### 第二步：连接服务器

购买完成后，获取：
- 服务器IP地址
- 用户名：root
- 密码（或SSH密钥）

**使用SSH连接**（Mac/Linux自带，Windows用PowerShell或PuTTY）：

```bash
ssh root@你的服务器IP
```

---

### 第三步：安装Docker

```bash
# 更新系统
apt update && apt upgrade -y

# 安装Docker
apt install -y docker.io docker-compose

# 启动Docker
systemctl start docker
systemctl enable docker

# 检查安装
docker --version
docker-compose --version
```

---

### 第四步：部署RSSHub

#### 4.1 创建工作目录

```bash
mkdir -p /opt/rsshub
cd /opt/rsshub
```

#### 4.2 创建docker-compose.yml

```bash
cat > docker-compose.yml << 'EOF'
version: '3'

services:
  rsshub:
    image: diygod/rsshub:latest
    container_name: rsshub
    ports:
      - "1200:1200"
    environment:
      - NODE_ENV=production
      - CACHE_TYPE=memory
      - CACHE_EXPIRE=300
      - CACHE_CONTENT_EXPIRE=3600
      - REQUEST_RETRY=3
      - REQUEST_TIMEOUT=30000
      # 反爬设置（可选）
      # - HTTP_PROXY=http://代理IP:端口
    restart: always
    volumes:
      - ./config:/app/config
EOF
```

#### 4.3 启动服务

```bash
docker-compose up -d
```

#### 4.4 检查状态

```bash
# 查看容器状态
docker ps

# 查看日志
docker logs -f rsshub
```

看到 `Listening Port 1200` 表示启动成功！

---

### 第五步：访问RSSHub

**浏览器访问**：
```
http://你的服务器IP:1200
```

看到RSSHub首页表示部署成功！

---

## 📰 配置微信公众号RSS

### 微信公众号路由

RSSHub支持通过**搜狗微信搜索**获取公众号文章：

**URL格式**：
```
http://你的服务器IP:1200/wechat/sogou/公众号名称
```

**示例**：
- 公众号「唐书房」：
  ```
  http://你的服务器IP:1200/wechat/sogou/唐书房
  ```
- 公众号「刘备教授」：
  ```
  ```
  http://你的服务器IP:1200/wechat/sogou/刘备教授
  ```

### 获取公众号RSS链接

1. **方式一：直接访问搜狗搜索**
   - 访问 https://weixin.sogou.com/
   - 搜索公众号名称
   - 复制链接中的微信号

2. **方式二：RSSHub自动识别**
   - 直接访问 `http://你的服务器IP:1200/wechat/sogou/公众号名称`
   - 如果能获取到文章，会返回RSS Feed

---

## 🤖 配置自动化日报

### 方案A：使用RSS阅读器（简单）

**推荐：Inoreader（免费版够用）**

1. 注册 Inoreader 账号：https://www.inoreader.com/
2. 添加订阅源：把你生成的公众号RSS链接都添加进去
3. 每天早上手动查看，或转发给我总结

### 方案B：自动化脚本（推荐）

我帮你创建一个自动抓取并生成日报的脚本：

```bash
# 在服务器上创建脚本目录
mkdir -p /opt/rsshub/scripts
cd /opt/rsshub/scripts
```

创建脚本 `generate_daily_report.sh`：

```bash
#!/bin/bash

# 配置
RSSHUB_URL="http://localhost:1200"
DATE=$(date +%Y-%m-%d)
OUTPUT_DIR="/opt/rsshub/reports"

# 公众号列表（请修改为你关注的公众号）
declare -A ACCOUNTS
ACCOUNTS=(
    ["公众号1"]="wechat/sogou/公众号1"
    ["公众号2"]="wechat/sogou/公众号2"
    # 添加更多...
)

# 创建输出目录
mkdir -p "$OUTPUT_DIR"

# 生成日报
REPORT_FILE="$OUTPUT_DIR/${DATE}-investment-news.md"

echo "# 📰 投资资讯日报 - ${DATE}" > "$REPORT_FILE"
echo "" >> "$REPORT_FILE"
echo "**抓取时间**: 北京时间 ${DATE} $(date +%H:%M)" >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"
echo "**数据来源**: 微信公众号 RSS" >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"
echo "---" >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"

for name in "${!ACCOUNTS[@]}"; do
    route="${ACCOUNTS[$name]}"
    echo "## ${name}" >> "$REPORT_FILE"
    echo "" >> "$REPORT_FILE"
    echo "- RSS链接: ${RSSHUB_URL}/${route}" >> "$REPORT_FILE"
    echo "" >> "$REPORT_FILE"
done

echo "日报已生成: $REPORT_FILE"
```

设置定时任务（每天早上9点执行）：

```bash
chmod +x /opt/rsshub/scripts/generate_daily_report.sh

# 添加定时任务
echo "0 9 * * * root /opt/rsshub/scripts/generate_daily_report.sh" >> /etc/crontab

# 重启cron
service cron restart
```

---

## 🔐 安全加固（可选）

### 1. 配置防火墙

```bash
# 只开放必要端口
ufw allow 22/tcp    # SSH
ufw allow 1200/tcp  # RSSHub
ufw enable
```

### 2. 配置Nginx反向代理（推荐）

```bash
apt install -y nginx

cat > /etc/nginx/sites-available/rsshub << 'EOF'
server {
    listen 80;
    server_name 你的域名或IP;

    location / {
        proxy_pass http://127.0.0.1:1200;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
EOF

ln -s /etc/nginx/sites-available/rsshub /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

---

## 📊 维护与监控

### 日常维护命令

```bash
# 查看RSSHub状态
docker ps

# 查看日志
docker logs -f rsshub

# 重启RSSHub
docker-compose restart

# 更新RSSHub
docker-compose pull
docker-compose up -d

# 备份配置
cp -r /opt/rsshub/config /opt/rsshub/config.backup.$(date +%Y%m%d)
```

### 反爬策略（如遇到搜狗限制）

如果搜狗反爬导致抓取失败，可以：

1. **更换User-Agent**（在环境变量中配置）
2. **使用代理IP**（添加HTTP_PROXY环境变量）
3. **降低抓取频率**（调整CACHE_EXPIRE）

---

## 💰 成本总结

| 项目 | 费用 | 备注 |
|------|------|------|
| 服务器 | ￥24-50/月 | 阿里云香港轻量 |
| 域名 | ￥0-60/年 | 可选 |
| 代理IP | ￥0-50/月 | 如遇到反爬才需要 |
| **总计** | **￥24-100/月** | 基础版约￥24/月 |

---

## ✅ 部署检查清单

- [ ] 购买服务器（香港节点）
- [ ] 连接服务器（SSH）
- [ ] 安装Docker
- [ ] 部署RSSHub
- [ ] 访问RSSHub首页
- [ ] 测试微信公众号RSS
- [ ] 配置自动化脚本
- [ ] 设置定时任务（每天9点）
- [ ] 测试日报生成

---

## 🆘 常见问题

### Q1: 搜狗反爬，获取不到文章？
**A**: 
- 尝试降低抓取频率
- 添加代理IP
- 或更换为其他数据源（如酷狗、Newrank）

### Q2: RSSHub启动失败？
**A**:
- 检查端口1200是否被占用：`netstat -tunlp | grep 1200`
- 检查Docker日志：`docker logs rsshub`
- 确保内存充足：`free -h`

### Q3: 如何添加更多公众号？
**A**:
- 编辑 `/opt/rsshub/scripts/generate_daily_report.sh`
- 在ACCOUNTS数组中添加新的公众号

### Q4: 数据安全吗？
**A**:
- RSSHub只生成RSS Feed，不存储文章内容
- 建议定期备份配置
- 敏感数据不要放在服务器上

---

## 📞 下一步

1. **先买服务器**：推荐阿里云香港轻量（24元/月）
2. **告诉我服务器IP和密码**：我可以远程帮你部署
3. **或者你自己按指南操作**：有问题随时问我
4. **准备公众号列表**：部署完成后立即配置

准备好开始了吗？🚀
