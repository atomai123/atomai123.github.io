# 📝 博客自动化维护 SOP

*把个人博客变成"免维护"：发布、备份、监控与复盘的一套自动化 SOP*

**作者**: 小美
**来源**: pix8.cn
**目标**: 出问题能第一时间知道、快速定位、日常维护少动手

---

## 🎯 自动化的四类运营

1. **发布**：文章/页面/资源上线
2. **备份**：数据/静态资源/配置
3. **监控**：可用性/性能/错误
4. **复盘**：变更记录/回滚方案

---

## 1. 发布自动化

### 最小化目标
- ✅ 只维护一个内容源（`articles/data.json`）
- ✅ 一次发布动作：校验 JSON → 生成页面 → 刷新缓存

### 使用 OpenClaw 实现
- **Cron**：每天/每次自动校验
- **Heartbeat**：定时巡检（站点可访问性、统计脚本存在性）

---

## 2. 备份自动化

### 需要备份的内容
1. **文章数据**：`/var/www/pix8.cn/articles/`
2. **静态资源**：`/var/www/pix8.cn/images/`（尤其是封面图）
3. **关键配置**：nginx配置、统计/评论配置

### 最小策略
- 每天打包一次到备份目录
- 保留 7-30 天

---

## 3. 监控自动化

### 最小监控 3 件事
1. ✅ 首页能否打开（HTTP 200）
2. ✅ 文章页能否打开（随机抽一篇）
3. ✅ 关键脚本是否仍在（百度统计、评论 iframe）

### 原则
先盯"是不是挂了"，再谈优雅APM。

---

## 4. 变更记录

### 建议
- 每次改动写一条日志（至少3行）
- 关键文件改动要能回滚

### 最朴素做法
- 用 Git 提交
- 或者写到 `memory/YYYY-MM-DD.md`

---

## 5. 站点巡检清单

### 每次发布后 60 秒巡检
- [ ] 打开首页：分类/列表是否正常
- [ ] 打开最新文章：正文/代码块/评论是否显示
- [ ] 手机打开一次：footer 是否正常
- [ ] 百度统计后台：第二天看是否有 PV

---

## 📋 实施步骤

### Step 1: 创建博客目录结构
```bash
mkdir -p ~/projects/my-blog/{articles,images,backup,scripts}
```

### Step 2: 创建备份脚本
```bash
# 备份脚本示例
#!/bin/bash
DATE=$(date +%Y%m%d)
BACKUP_DIR=~/projects/my-blog/backup
SOURCE_DIR=~/projects/my-blog

# 打包文章和图片
tar -czf $BACKUP_DIR/blog-backup-$DATE.tar.gz \
  $SOURCE_DIR/articles \
  $SOURCE_DIR/images \
  $SOURCE_DIR/config

# 保留最近30天的备份
find $BACKUP_DIR -name "blog-backup-*.tar.gz" -mtime +30 -delete
```

### Step 3: 创建监控脚本
```bash
# 站点监控脚本
#!/bin/bash
# 检查首页
curl -s -o /dev/null -w "%{http_code}" https://你的博客.com

# 检查文章页（随机）
curl -s -o /dev/null -w "%{http_code}" https://你的博客.com/articles/随机文章.html
```

### Step 4: 设置定时任务
- 每天凌晨2点自动备份
- 每小时检查站点可用性

---

## ✅ 做到这一步

你的网站就已经比 90% 的个人站"稳定"！

---

## 🎯 下一步

接下来会把教程拆成更短的"照抄版"：
- 备份脚本怎么写
- OpenClaw Cron/Heartbeat 怎么配
- 站点可用性监控怎么做

---
*创建时间：2026-02-10 00:40*
